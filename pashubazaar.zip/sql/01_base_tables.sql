-- Run first
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz default now(),
  full_name text,
  phone text,
  avatar_url text,
  role text default 'farmer' check (role in ('farmer','buyer','admin'))
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  owner_id uuid references auth.users(id) on delete cascade,
  title text not null,
  description text,
  species text not null,
  breed text,
  age_months int,
  weight_kg numeric,
  price numeric not null,
  location text,
  status text default 'active' check (status in ('active','sold','hidden'))
);

create table if not exists public.listing_media (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  listing_id uuid references public.listings(id) on delete cascade,
  kind text not null check (kind in ('image','video')),
  path text not null
);

create table if not exists public.threads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  listing_id uuid references public.listings(id) on delete cascade,
  buyer_id uuid references auth.users(id) on delete cascade,
  seller_id uuid references auth.users(id) on delete cascade,
  unique(listing_id, buyer_id, seller_id)
);

create table if not exists public.messages (
  id bigserial primary key,
  created_at timestamptz default now(),
  thread_id uuid references public.threads(id) on delete cascade,
  sender_id uuid references auth.users(id) on delete cascade,
  body text not null
);

create table if not exists public.favourites (
  user_id uuid references auth.users(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, listing_id)
);
