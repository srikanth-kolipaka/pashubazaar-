-- Run second
alter table public.profiles       enable row level security;
alter table public.listings       enable row level security;
alter table public.listing_media  enable row level security;
alter table public.threads        enable row level security;
alter table public.messages       enable row level security;
alter table public.favourites     enable row level security;

drop policy if exists "profiles_select_self_or_public" on public.profiles;
drop policy if exists "profiles_insert_owner" on public.profiles;
drop policy if exists "profiles_update_owner" on public.profiles;

drop policy if exists "listings_select_all" on public.listings;
drop policy if exists "listings_insert_owner" on public.listings;
drop policy if exists "listings_update_owner" on public.listings;
drop policy if exists "listings_delete_owner" on public.listings;

drop policy if exists "media_select_all" on public.listing_media;
drop policy if exists "media_insert_owner" on public.listing_media;
drop policy if exists "media_delete_owner" on public.listing_media;

drop policy if exists "threads_select_participants" on public.threads;
drop policy if exists "threads_insert_buyer_or_seller" on public.threads;

drop policy if exists "messages_select_participants" on public.messages;
drop policy if exists "messages_insert_participants" on public.messages;

drop policy if exists "fav_select_own_or_public" on public.favourites;
drop policy if exists "fav_insert_own" on public.favourites;
drop policy if exists "fav_delete_own" on public.favourites;

create policy "profiles_select_self_or_public" on public.profiles for select using (true);
create policy "profiles_insert_owner" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_owner" on public.profiles for update using (auth.uid() = id);

create policy "listings_select_all" on public.listings for select using (true);
create policy "listings_insert_owner" on public.listings for insert with check (auth.uid() = owner_id);
create policy "listings_update_owner" on public.listings for update using (auth.uid() = owner_id);
create policy "listings_delete_owner" on public.listings for delete using (auth.uid() = owner_id);

create policy "media_select_all" on public.listing_media for select using (true);
create policy "media_insert_owner" on public.listing_media for insert with check (exists (select 1 from public.listings l where l.id = listing_id and l.owner_id = auth.uid()));
create policy "media_delete_owner" on public.listing_media for delete using (exists (select 1 from public.listings l where l.id = listing_id and l.owner_id = auth.uid()));

create policy "threads_select_participants" on public.threads for select using (auth.uid() = buyer_id or auth.uid() = seller_id);
create policy "threads_insert_buyer_or_seller" on public.threads for insert with check (auth.uid() = buyer_id or auth.uid() = seller_id);

create policy "messages_select_participants" on public.messages for select using (exists (select 1 from public.threads t where t.id = thread_id and (t.buyer_id = auth.uid() or t.seller_id = auth.uid())));
create policy "messages_insert_participants" on public.messages for insert with check (exists (select 1 from public.threads t where t.id = thread_id and (t.buyer_id = auth.uid() or t.seller_id = auth.uid())));

create policy "fav_select_own_or_public" on public.favourites for select using (true);
create policy "fav_insert_own" on public.favourites for insert with check (auth.uid() = user_id);
create policy "fav_delete_own" on public.favourites for delete using (auth.uid() = user_id);
