-- Run third (optional but recommended)
alter table public.listings add column if not exists state text;
alter table public.listings add column if not exists milk_yield_lpd numeric;
alter table public.listings add column if not exists vaccinated boolean default false;
alter table public.listings add column if not exists flagged boolean default false;

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz default now()
);

create table if not exists public.reports (
  id bigserial primary key,
  created_at timestamptz default now(),
  listing_id uuid references public.listings(id) on delete cascade,
  reporter_id uuid references auth.users(id) on delete cascade,
  reason text
);

alter table public.admins enable row level security;
alter table public.reports enable row level security;

drop policy if exists "admins_select_self" on public.admins;
drop policy if exists "reports_insert_any" on public.reports;
drop policy if exists "reports_select_admins" on public.reports;
drop policy if exists "listings_update_admin" on public.listings;

create policy "admins_select_self" on public.admins for select using (auth.uid() = user_id);
create policy "reports_insert_any" on public.reports for insert with check (auth.uid() is not null);
create policy "reports_select_admins" on public.reports for select using (exists (select 1 from public.admins a where a.user_id = auth.uid()));
create policy "listings_update_admin" on public.listings for update using (exists (select 1 from public.admins a where a.user_id = auth.uid()));
